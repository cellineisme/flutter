import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SignPage extends StatelessWidget {
  const SignPage({super.key});

  @override
  Widget namaUser() {
    return TextField(
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 20),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(23),
          borderSide: BorderSide(
            color: Color(0xff5C40CC),
          ),
        ),
        hintText: 'username',
        hintStyle: GoogleFonts.poppins(
          fontSize: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(17),
        ),
      ),
    );
  }

  Widget Email() {
    return TextField(
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 20),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(23),
          borderSide: BorderSide(
            color: Color(0xff5C40CC),
          ),
        ),
        hintText: 'email',
        hintStyle: GoogleFonts.poppins(
          fontSize: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(17),
        ),
      ),
    );
  }

  Widget pass() {
    return TextField(
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 20),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(23),
          borderSide: BorderSide(
            color: Color(0xff5C40CC),
          ),
        ),
        hintText: 'password',
        hintStyle: GoogleFonts.poppins(
          fontSize: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(17),
        ),
      ),
    );
  }

  Widget hobi() {
    return TextField(
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: 15.0, horizontal: 20),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(23),
          borderSide: BorderSide(
            color: Color(0xff5C40CC),
          ),
        ),
        hintText: 'basketball, etc',
        hintStyle: GoogleFonts.poppins(
          fontSize: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(17),
        ),
      ),
    );
  }

  Widget signinButton() {
    return Container(
      height: 48,
      width: 600,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(17),
        color: Color(0xff5C40CC),
      ),
      child: Center(
        child: Text(
          'DET STARTED',
          style: GoogleFonts.poppins(
            fontSize: 20,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffE5E5E5),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: EdgeInsets.only(
                right: 24,
                left: 24,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Join us and get\nyour new journey',
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.w600,
                        color: Color(0xff1F1449),
                      )),
                  SizedBox(height: 30),
                  Container(
                    padding: EdgeInsets.only(
                      right: 24,
                      left: 24,
                      top: 30,
                    ),
                    width: 366,
                    height: 533,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Full Name',
                          textAlign: TextAlign.left,
                          style: GoogleFonts.poppins(),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        namaUser(),
                        SizedBox(
                          height: 20,
                        ),
                        Text(
                          'Email',
                          textAlign: TextAlign.left,
                          style: GoogleFonts.poppins(),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        Email(),
                        SizedBox(
                          height: 20,
                        ),
                        Text(
                          'Password',
                          textAlign: TextAlign.left,
                          style: GoogleFonts.poppins(),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        pass(),
                        SizedBox(
                          height: 20,
                        ),
                        Text(
                          'Hobby',
                          textAlign: TextAlign.left,
                          style: GoogleFonts.poppins(),
                        ),
                        SizedBox(
                          height: 6,
                        ),
                        hobi(),
                        SizedBox(
                          height: 20,
                        ),
                        Center(
                          child: Column(
                            children: [
                              signinButton(),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Center(
                    child: Column(
                      children: [
                        Text(
                          'Terms and Condition',
                          style: GoogleFonts.poppins(
                            fontSize: 15,
                            decoration: TextDecoration.underline,
                            fontWeight: FontWeight.w300,
                            color: Color(0xff9698A9),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
